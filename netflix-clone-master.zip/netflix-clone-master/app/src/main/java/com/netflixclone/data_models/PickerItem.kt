package com.netflixclone.data_models

data class PickerItem(
        val text: String,
)