package com.netflixclone.screens

import androidx.fragment.app.Fragment

open class BottomNavFragment : Fragment() {
    open fun onFirstDisplay() {
    }
}