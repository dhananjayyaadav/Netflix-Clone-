package com.netflixclone.data_models

data class Genre(val id: Int, val name: String)